import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Categories } from './components/Categories';
import { FeaturedCarWashes } from './components/FeaturedCarWashes';
import { CarWashList } from './components/CarWashList';
import { About } from './components/About';
import { LoginModal } from './components/auth/LoginModal';
import { RegisterModal } from './components/auth/RegisterModal';
import { UserProfile } from './components/profile/UserProfile';
import { useAuthStore } from './store/authStore';
import { auth } from './config/firebase';
import { onAuthStateChanged } from 'firebase/auth';

function App() {
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const { setUser } = useAuthStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return () => unsubscribe();
  }, [setUser]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onLoginClick={() => setShowLogin(true)}
        onProfileClick={() => setShowProfile(true)}
      />
      <main className="pt-16">
        <section id="inicio">
          <Hero />
        </section>
        <section id="servicos">
          <Categories />
          <FeaturedCarWashes />
          <CarWashList />
        </section>
        <About />
        {showProfile && <UserProfile />}
      </main>

      {showLogin && (
        <LoginModal
          onClose={() => setShowLogin(false)}
          onSwitchToRegister={() => {
            setShowLogin(false);
            setShowRegister(true);
          }}
        />
      )}

      {showRegister && (
        <RegisterModal
          onClose={() => setShowRegister(false)}
          onSwitchToLogin={() => {
            setShowRegister(false);
            setShowLogin(true);
          }}
        />
      )}
    </div>
  );
}

export default App;