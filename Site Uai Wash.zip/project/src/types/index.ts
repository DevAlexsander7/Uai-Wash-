export interface CarWash {
  id: string;
  name: string;
  rating: number;
  image: string;
  address: string;
  location: {
    lat: number;
    lng: number;
  };
  services: Service[];
  openingHours: string;
  deliveryTime: string;
  category: string[];
  featured?: boolean;
  promotion?: string;
  hasPickupService: boolean;
  distanceKm?: number;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  duration: string;
  description: string;
  popular?: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface Location {
  address: string;
  lat: number;
  lng: number;
}