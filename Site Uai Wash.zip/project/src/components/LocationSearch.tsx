import React, { useState } from 'react';
import { Search, MapPin } from 'lucide-react';
import { useStore } from '../store/useStore';

export function LocationSearch() {
  const { setUserLocation, searchQuery, setSearchQuery } = useStore();
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);

    try {
      // In a real application, you would use a geocoding service like Google Maps
      // Here we're simulating the geocoding with a mock response
      const mockLocation = {
        address: searchQuery,
        lat: -19.917299, // Example coordinates for Belo Horizonte
        lng: -43.934559,
      };

      setUserLocation(mockLocation);
    } catch (error) {
      console.error('Error getting location:', error);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <form onSubmit={handleSearch} className="relative max-w-2xl mx-auto mb-12">
      <div className="relative">
        <MapPin className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Digite seu endereço..."
          className="w-full pl-14 pr-20 py-4 rounded-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-300 text-lg"
        />
        <button 
          type="submit"
          disabled={isSearching}
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-700 p-4 rounded-full hover:bg-blue-800 transition-colors disabled:opacity-75"
        >
          <Search className="w-6 h-6" />
        </button>
      </div>
      <p className="absolute left-6 mt-2 text-sm text-blue-200">
        Encontre lava-jatos próximos a você
      </p>
    </form>
  );
}