import React from 'react';
import { Car, Sparkles, Disc, Droplets } from 'lucide-react';
import { categories } from '../data/categories';

const iconMap = {
  car: Car,
  sparkles: Sparkles,
  disc: Disc,
  droplets: Droplets,
};

export function Categories() {
  return (
    <div className="py-8 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-xl font-bold mb-6">Categorias</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((category) => {
            const Icon = iconMap[category.icon];
            return (
              <button
                key={category.id}
                className="flex flex-col items-center p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                <Icon className="w-8 h-8 mb-2 text-blue-600" />
                <span className="text-sm font-medium text-gray-900">{category.name}</span>
                <span className="text-xs text-gray-500 text-center mt-1">
                  {category.description}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}