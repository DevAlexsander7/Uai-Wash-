import React, { useState } from 'react';
import { Clock, Timer, ChevronRight, Car, MapPin } from 'lucide-react';
import { CarWash, Service } from '../types';
import { BookingModal } from './BookingModal';
import { CarWashDetailsModal } from './CarWashDetailsModal';
import { useAuthStore } from '../store/authStore';
import { Rating } from './ui/Rating';
import { Badge } from './ui/Badge';
import { FadeIn } from './animations/FadeIn';

interface CarWashCardProps {
  carWash: CarWash;
  onLoginRequired: () => void;
  index: number;
}

export function CarWashCard({ carWash, onLoginRequired, index }: CarWashCardProps) {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const { user } = useAuthStore();

  const handleBookingClick = (service: Service) => {
    if (!user) {
      onLoginRequired();
    } else {
      setSelectedService(service);
    }
  };

  return (
    <FadeIn delay={index * 0.1}>
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
        <div className="relative">
          <img 
            src={carWash.image} 
            alt={carWash.name}
            className="w-full h-48 object-cover"
          />
          {carWash.promotion && (
            <div className="absolute top-4 left-4">
              <Badge variant="warning">{carWash.promotion}</Badge>
            </div>
          )}
        </div>
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-xl font-semibold">{carWash.name}</h3>
            {carWash.hasPickupService && (
              <Badge variant="success" size="sm">
                <Car className="w-3 h-3 mr-1" />
                Busca e entrega
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-4 mb-2">
            <Rating value={carWash.rating} />
            <div className="flex items-center text-gray-500">
              <Timer className="w-4 h-4 mr-1" />
              <span className="text-sm">{carWash.deliveryTime}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-3">
            {carWash.category.map((cat, index) => (
              <Badge key={index} variant="primary" size="sm">
                {cat}
              </Badge>
            ))}
          </div>

          <div className="flex items-start space-x-2 text-gray-600 mb-2">
            <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
            <div>
              <p>{carWash.address}</p>
              {carWash.distanceKm !== undefined && (
                <p className="text-sm text-blue-600 font-medium">
                  {carWash.distanceKm} km de distância
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center text-gray-500 mb-4">
            <Clock className="w-4 h-4 mr-1" />
            <span className="text-sm">{carWash.openingHours}</span>
          </div>
          
          <button
            onClick={() => setShowDetails(true)}
            className="w-full py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
          >
            <span>Ver serviços</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      {showDetails && (
        <CarWashDetailsModal
          carWash={carWash}
          onClose={() => setShowDetails(false)}
          onBookService={handleBookingClick}
        />
      )}
      
      {selectedService && user && (
        <BookingModal
          carWash={carWash}
          service={selectedService}
          onClose={() => setSelectedService(null)}
        />
      )}
    </FadeIn>
  );
}