import React, { useState } from 'react';
import { Car, UserCircle2, LogOut } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { LoginModal } from './auth/LoginModal';
import { RegisterModal } from './auth/RegisterModal';

export function Header() {
  const { user, signOut } = useAuthStore();
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSwitchToRegister = () => {
    setShowLoginModal(false);
    setShowRegisterModal(true);
  };

  const handleSwitchToLogin = () => {
    setShowRegisterModal(false);
    setShowLoginModal(true);
  };

  return (
    <>
      <header className="bg-blue-600 text-white fixed w-full z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Car size={32} />
              <h1 className="text-2xl font-bold">UAi WASH</h1>
            </div>
            <nav className="flex items-center space-x-8">
              <ul className="flex space-x-6">
                <li>
                  <button 
                    onClick={() => scrollToSection('inicio')} 
                    className="hover:text-blue-200 transition-colors"
                  >
                    Início
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('servicos')} 
                    className="hover:text-blue-200 transition-colors"
                  >
                    Serviços
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('sobre')} 
                    className="hover:text-blue-200 transition-colors"
                  >
                    Sobre
                  </button>
                </li>
              </ul>
              
              <div className="flex items-center space-x-4">
                {user ? (
                  <div className="flex items-center space-x-3">
                    <span className="text-sm">{user.email}</span>
                    <button
                      onClick={() => signOut()}
                      className="flex items-center space-x-1 hover:text-blue-200 transition-colors"
                    >
                      <LogOut size={20} />
                      <span className="text-sm">Sair</span>
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowLoginModal(true)}
                    className="flex items-center space-x-1 hover:text-blue-200 transition-colors"
                  >
                    <UserCircle2 size={24} />
                    <span>Entrar</span>
                  </button>
                )}
              </div>
            </nav>
          </div>
        </div>
      </header>

      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onSwitchToRegister={handleSwitchToRegister}
        />
      )}

      {showRegisterModal && (
        <RegisterModal
          onClose={() => setShowRegisterModal(false)}
          onSwitchToLogin={handleSwitchToLogin}
        />
      )}
    </>
  );
}