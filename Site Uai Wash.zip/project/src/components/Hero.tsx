import React from 'react';
import { Shield, Star, Clock } from 'lucide-react';
import { LocationSearch } from './LocationSearch';

export function Hero() {
  return (
    <div className="relative bg-blue-600 text-white py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-5xl font-bold mb-6">Seu Carro Limpo em Poucos Cliques</h2>
          <p className="text-xl mb-8">
            Encontre e agende os melhores serviços de lavagem automotiva perto de você
          </p>
          <LocationSearch />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="flex items-center space-x-3 bg-blue-700 rounded-lg p-4">
            <Shield className="w-10 h-10 flex-shrink-0" />
            <div>
              <h3 className="font-semibold">Segurança Garantida</h3>
              <p className="text-blue-200 text-sm">Parceiros verificados</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 bg-blue-700 rounded-lg p-4">
            <Star className="w-10 h-10 flex-shrink-0" />
            <div>
              <h3 className="font-semibold">Avaliações Reais</h3>
              <p className="text-blue-200 text-sm">Feedback dos clientes</p>
            </div>
          </div>
          <div className="flex items-center space-x-3 bg-blue-700 rounded-lg p-4">
            <Clock className="w-10 h-10 flex-shrink-0" />
            <div>
              <h3 className="font-semibold">Agendamento Fácil</h3>
              <p className="text-blue-200 text-sm">Horários flexíveis</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}