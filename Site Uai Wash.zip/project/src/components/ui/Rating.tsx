import React from 'react';
import { Star, StarHalf } from 'lucide-react';

interface RatingProps {
  value: number;
  size?: 'sm' | 'md' | 'lg';
}

export function Rating({ value, size = 'md' }: RatingProps) {
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  const fullStars = Math.floor(value);
  const hasHalfStar = value % 1 >= 0.5;
  const iconSize = sizes[size];

  return (
    <div className="flex items-center">
      {[...Array(fullStars)].map((_, i) => (
        <Star key={`star-${i}`} className={`${iconSize} text-yellow-400 fill-current`} />
      ))}
      {hasHalfStar && <StarHalf className={`${iconSize} text-yellow-400`} />}
      <span className="ml-1 font-medium">{value.toFixed(1)}</span>
    </div>
  );
}