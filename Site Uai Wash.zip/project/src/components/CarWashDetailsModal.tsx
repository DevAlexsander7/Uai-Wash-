import React from 'react';
import { X, Star, Clock, Timer, MapPin, Phone } from 'lucide-react';
import { CarWash, Service } from '../types';
import { useAuthStore } from '../store/authStore';

interface CarWashDetailsModalProps {
  carWash: CarWash;
  onClose: () => void;
  onBookService: (service: Service) => void;
}

export function CarWashDetailsModal({ carWash, onClose, onBookService }: CarWashDetailsModalProps) {
  const { user } = useAuthStore();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="relative">
          <img 
            src={carWash.image} 
            alt={carWash.name}
            className="w-full h-64 object-cover rounded-t-lg"
          />
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-white p-2 rounded-full shadow-lg hover:bg-gray-100"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-2">{carWash.name}</h2>
            <div className="flex flex-wrap items-center gap-4 text-gray-600 mb-4">
              <div className="flex items-center">
                <Star className="w-5 h-5 text-yellow-400 mr-1" />
                <span className="font-medium">{carWash.rating}</span>
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                <span>{carWash.openingHours}</span>
              </div>
              <div className="flex items-center">
                <Timer className="w-4 h-4 mr-1" />
                <span>{carWash.deliveryTime}</span>
              </div>
            </div>
            <div className="flex items-start space-x-2 text-gray-600">
              <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>{carWash.address}</span>
            </div>
          </div>

          {carWash.promotion && (
            <div className="bg-red-50 border border-red-100 rounded-lg p-4 mb-6">
              <p className="text-red-600 font-medium">{carWash.promotion}</p>
            </div>
          )}

          <div>
            <h3 className="text-xl font-semibold mb-4">Serviços Disponíveis</h3>
            <div className="space-y-4">
              {carWash.services.map(service => (
                <div 
                  key={service.id}
                  className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors"
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-medium">{service.name}</h4>
                      <p className="text-gray-600 text-sm">{service.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-lg">R$ {service.price}</p>
                      <p className="text-sm text-gray-500">{service.duration}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => onBookService(service)}
                    className="w-full mt-2 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    {user ? 'Agendar Serviço' : 'Entrar para Agendar'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}