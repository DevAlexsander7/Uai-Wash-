import React, { useState } from 'react';
import { X, CreditCard } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { Service } from '../../types';

const stripePromise = loadStripe('your_publishable_key');

interface PaymentModalProps {
  service: Service;
  onClose: () => void;
  onSuccess: () => void;
}

export function PaymentModal({ service, onClose, onSuccess }: PaymentModalProps) {
  const [loading, setLoading] = useState(false);

  const handlePayment = async () => {
    try {
      setLoading(true);
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe não carregou');

      // Aqui você implementaria a chamada ao seu backend para criar a sessão do Stripe
      // const response = await fetch('/api/create-checkout-session', ...);
      // const session = await response.json();
      // await stripe.redirectToCheckout({ sessionId: session.id });

      onSuccess();
    } catch (error) {
      console.error('Erro no pagamento:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Pagamento</h3>
          <button onClick={onClose} className="p-1">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Resumo do Serviço</h4>
            <p className="text-gray-600">{service.name}</p>
            <p className="text-lg font-semibold mt-2">R$ {service.price.toFixed(2)}</p>
          </div>

          <button
            onClick={handlePayment}
            disabled={loading}
            className="w-full py-3 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center space-x-2"
          >
            <CreditCard className="w-5 h-5" />
            <span>{loading ? 'Processando...' : 'Pagar com Cartão'}</span>
          </button>

          <p className="text-sm text-gray-500 text-center">
            Pagamento seguro processado pela Stripe
          </p>
        </div>
      </div>
    </div>
  );
}