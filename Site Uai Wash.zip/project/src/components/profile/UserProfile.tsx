import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { useStore } from '../../store/useStore';
import { Clock, Car } from 'lucide-react';

export function UserProfile() {
  const { user } = useAuthStore();
  const bookings = useStore((state) => state.bookings);

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-6">Meu Perfil</h2>
        
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Informações Pessoais</h3>
          <p className="text-gray-600">Email: {user.email}</p>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-4">Meus Agendamentos</h3>
          {bookings.length === 0 ? (
            <p className="text-gray-500">Você ainda não tem agendamentos.</p>
          ) : (
            <div className="space-y-4">
              {bookings.map((booking, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="w-5 h-5 text-blue-600" />
                    <span className="font-medium">
                      {booking.date} às {booking.time}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-gray-600">
                    <Car className="w-5 h-5" />
                    <span>{booking.userDetails.carModel}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}