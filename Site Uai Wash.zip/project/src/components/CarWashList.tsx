import React, { useState } from 'react';
import { CarWashCard } from './CarWashCard';
import { useStore } from '../store/useStore';
import { LoginModal } from './auth/LoginModal';
import { RegisterModal } from './auth/RegisterModal';
import { FadeIn } from './animations/FadeIn';

export function CarWashList() {
  const filteredCarWashes = useStore((state) => state.filteredCarWashes());
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  const handleSwitchToRegister = () => {
    setShowLoginModal(false);
    setShowRegisterModal(true);
  };

  const handleSwitchToLogin = () => {
    setShowRegisterModal(false);
    setShowLoginModal(true);
  };

  return (
    <>
      <div className="container mx-auto px-4 py-12">
        <FadeIn>
          <h2 className="text-2xl font-bold mb-8">Lava-Rápidos Disponíveis</h2>
        </FadeIn>
        
        {filteredCarWashes.length === 0 ? (
          <FadeIn>
            <div className="text-center py-12">
              <div className="text-gray-500 mb-4">
                Nenhum lava-rápido encontrado para sua busca.
              </div>
              <p className="text-sm text-gray-400">
                Tente ajustar seus critérios de busca ou procurar em outra localização.
              </p>
            </div>
          </FadeIn>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCarWashes.map((carWash, index) => (
              <CarWashCard 
                key={carWash.id} 
                carWash={carWash} 
                onLoginRequired={() => setShowLoginModal(true)}
                index={index}
              />
            ))}
          </div>
        )}
      </div>

      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onSwitchToRegister={handleSwitchToRegister}
        />
      )}

      {showRegisterModal && (
        <RegisterModal
          onClose={() => setShowRegisterModal(false)}
          onSwitchToLogin={handleSwitchToLogin}
        />
      )}
    </>
  );
}