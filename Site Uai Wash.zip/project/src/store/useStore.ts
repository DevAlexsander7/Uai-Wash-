import { create } from 'zustand';
import { CarWash, Service, Location } from '../types';
import { carWashes as initialCarWashes } from '../data/carWashes';
import { calculateDistance } from '../utils/distance';

interface Booking {
  carWashId: string;
  serviceId: string;
  date: string;
  time: string;
  userDetails: {
    name: string;
    phone: string;
    carModel: string;
  };
}

interface Store {
  carWashes: CarWash[];
  searchQuery: string;
  selectedCategory: string | null;
  selectedCarWash: CarWash | null;
  bookings: Booking[];
  userLocation: Location | null;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: string | null) => void;
  setSelectedCarWash: (carWash: CarWash | null) => void;
  addBooking: (booking: Booking) => void;
  setUserLocation: (location: Location) => void;
  filteredCarWashes: () => CarWash[];
}

export const useStore = create<Store>((set, get) => ({
  carWashes: initialCarWashes,
  searchQuery: '',
  selectedCategory: null,
  selectedCarWash: null,
  bookings: [],
  userLocation: null,
  
  setSearchQuery: (query) => set({ searchQuery: query }),
  setSelectedCategory: (category) => set({ selectedCategory: category }),
  setSelectedCarWash: (carWash) => set({ selectedCarWash: carWash }),
  addBooking: (booking) => set((state) => ({ 
    bookings: [...state.bookings, booking] 
  })),
  setUserLocation: (location) => set({ userLocation: location }),
  
  filteredCarWashes: () => {
    const { carWashes, searchQuery, selectedCategory, userLocation } = get();
    let filtered = [...carWashes];
    
    if (searchQuery) {
      filtered = filtered.filter((carWash) => 
        carWash.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        carWash.address.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    if (selectedCategory) {
      filtered = filtered.filter((carWash) =>
        carWash.category.includes(selectedCategory)
      );
    }
    
    if (userLocation) {
      filtered = filtered.map(carWash => ({
        ...carWash,
        distanceKm: calculateDistance(
          userLocation.lat,
          userLocation.lng,
          carWash.location.lat,
          carWash.location.lng
        )
      })).sort((a, b) => (a.distanceKm || 0) - (b.distanceKm || 0));
    }
    
    return filtered;
  },
}));