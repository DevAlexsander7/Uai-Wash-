import { Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Lavagem Básica',
    icon: 'car',
    description: 'Lavagem simples e rápida'
  },
  {
    id: '2',
    name: 'Lavagem Premium',
    icon: 'sparkles',
    description: 'Serviço completo com enceramento'
  },
  {
    id: '3',
    name: 'Polimento',
    icon: 'disc',
    description: 'Polimento profissional'
  },
  {
    id: '4',
    name: 'Higienização',
    icon: 'droplets',
    description: 'Limpeza interna completa'
  }
];