import { CarWash } from '../types';

export const carWashes: CarWash[] = [
  {
    id: '1',
    name: 'Premium Auto Spa',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?auto=format&fit=crop&w=800&q=80',
    address: 'Av. Amazonas, 1234 - Centro',
    location: {
      lat: -19.917299,
      lng: -43.934559
    },
    openingHours: '08:00 - 20:00',
    deliveryTime: '30-45 min',
    category: ['Lavagem Premium', 'Polimento'],
    featured: true,
    promotion: '15% OFF em lavagens premium',
    hasPickupService: true,
    services: [
      {
        id: '1',
        name: 'Lavagem Básica',
        price: 30,
        duration: '30min',
        description: 'Lavagem externa e limpeza básica do interior',
        popular: true
      },
      {
        id: '2',
        name: 'Detalhamento Premium',
        price: 120,
        duration: '2h',
        description: 'Detalhamento completo interno e externo com cera'
      }
    ]
  },
  {
    id: '2',
    name: 'Eco Car Wash',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1605164599901-db99fae8dcd0?auto=format&fit=crop&w=800&q=80',
    address: 'Rua das Palmeiras, 567 - Jardim',
    location: {
      lat: -19.927299,
      lng: -43.944559
    },
    openingHours: '07:00 - 19:00',
    deliveryTime: '20-35 min',
    category: ['Lavagem Básica', 'Higienização'],
    promotion: 'Ganhe uma cera na primeira lavagem',
    hasPickupService: false,
    services: [
      {
        id: '3',
        name: 'Lavagem Ecológica',
        price: 40,
        duration: '45min',
        description: 'Lavagem ecológica com reaproveitamento de água',
        popular: true
      }
    ]
  }
];