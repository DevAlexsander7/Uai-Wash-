import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyC1i5c1Ni-YwfI4BH5BVD5wbrQpJK17nVM",
  authDomain: "uaiwash.firebaseapp.com",
  projectId: "uaiwash",
  storageBucket: "uaiwash.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "8344872571"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);